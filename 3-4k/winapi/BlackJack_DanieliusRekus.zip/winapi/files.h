//read and write W/L + credits to/from file
#define WRITE_BUTTON 1115
#define READ_BUTTON 1116
